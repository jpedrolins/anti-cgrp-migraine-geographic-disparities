# Reviewed functions only; top-level historical workflow intentionally omitted.
def pearson_distance(tables):
    """A discrepancy statistic only: its reference distribution is NOT chi-square."""
    tables = np.asarray(tables, dtype=float)
    row = tables.sum(axis=-1, keepdims=True)
    col = tables.sum(axis=-2, keepdims=True)
    expected = row * col / tables.sum(axis=(-2, -1), keepdims=True)
    return np.divide((tables - expected) ** 2, expected,
                     out=np.zeros_like(expected), where=expected > 0).sum(axis=(-2, -1))

def cluster_permutation(data, variable, levels, name):
    """Move whole record profiles, preserving within-record dependence and group sizes."""
    d = data[(data[variable].isin(levels)) & data.participations.gt(0)]
    labels = pd.Categorical(d[variable], categories=levels).codes
    x = d[income_levels].to_numpy(dtype=float)
    table = np.stack([x[labels == g].sum(axis=0) for g in range(len(levels))])
    observed = float(pearson_distance(table))
    exceed = 0
    for start in range(0, CFG["resamples"], CFG["batch_size"]):
        batch = min(CFG["batch_size"], CFG["resamples"] - start)
        shuffled = RNG.permuted(np.broadcast_to(labels, (batch, len(labels))), axis=1)
        totals = np.stack([(shuffled == g).astype(float) @ x for g in range(len(levels))], axis=1)
        exceed += int(np.count_nonzero(pearson_distance(totals) >= observed - 1e-12))
    p = (exceed + 1) / (CFG["resamples"] + 1)
    result = {"stratum": name, "levels": levels, "n_records_in_test": len(d),
              "participations_in_test": int(x.sum()), "statistic": observed,
              "method": "Whole-record label permutation; Pearson discrepancy, not asymptotic chi-square",
              "resamples": CFG["resamples"], "exceedances": exceed, "p": p,
              "monte_carlo_se": float(np.sqrt(p * (1-p)/(CFG["resamples"]+1)))}
    print(name, levels, "P =", p, flush=True)
    return result

def scope_wild_cluster(data):
    """Fixed scope labels; joint linear-probability contrast with record-cluster covariance.

    Restricted wild cluster bootstrap uses one sign per record for all outcome
    indicators. This is approximate robust inference, NOT an exact randomization test.
    Scope labels are not permuted because they are defined by cluster size.
    """
    d = data[data.participations.gt(0)]
    x = d[["HIC", "UMIC"]].to_numpy(float)  # LMIC is redundant; LIC is globally zero.
    n = d.participations.to_numpy(float)
    g = d.scope_group.eq("Multicountry").to_numpy()
    probabilities, variances, ns, ms = [], [], [], []
    for mask in (~g, g):
        total = n[mask].sum()
        p = x[mask].sum(axis=0) / total
        residual = x[mask] - n[mask, None] * p
        m = int(mask.sum())
        probabilities.append(p)
        variances.append((residual.T @ residual) / total**2 * m/(m-1))
        ns.append(total); ms.append(m)
    delta = probabilities[1] - probabilities[0]
    variance = variances[0] + variances[1]
    assert np.linalg.matrix_rank(variance) == 2
    observed = float(delta @ np.linalg.solve(variance, delta))
    pooled = x.sum(axis=0) / n.sum()
    null_residual = x - n[:, None] * pooled
    exceed = 0
    singular = 0
    for start in range(0, CFG["resamples"], CFG["batch_size"]):
        batch = min(CFG["batch_size"], CFG["resamples"] - start)
        signs = RNG.choice([-1.0, 1.0], size=(batch, len(d)))
        wild = signs[:, :, None] * null_residual[None, :, :]
        star_prob, star_var = [], []
        for index, mask in enumerate((~g, g)):
            shift = wild[:, mask].sum(axis=1) / ns[index]
            residual = wild[:, mask] - n[None, mask, None] * shift[:, None, :]
            star_prob.append(shift)
            star_var.append(np.einsum("bni,bnj->bij", residual, residual)
                            / ns[index]**2 * ms[index]/(ms[index]-1))
        diff = star_prob[1] - star_prob[0]
        cov = star_var[0] + star_var[1]
        determinant = cov[:, 0, 0] * cov[:, 1, 1] - cov[:, 0, 1]**2
        ok = determinant > 1e-20
        singular += int((~ok).sum())
        stat = np.zeros(batch)
        stat[ok] = (cov[ok, 1, 1] * diff[ok, 0]**2
                    - 2*cov[ok, 0, 1]*diff[ok, 0]*diff[ok, 1]
                    + cov[ok, 0, 0]*diff[ok, 1]**2) / determinant[ok]
        exceed += int(np.count_nonzero(stat >= observed - 1e-12))
    assert singular == 0, "Do not silently omit singular bootstrap draws"
    p = (exceed + 1) / (CFG["resamples"] + 1)
    result = {"stratum": "Geographic scope", "levels": ["Single-country", "Multicountry"],
              "n_records_in_test": len(d), "participations_in_test": int(n.sum()),
              "statistic": observed, "method": "Joint cluster-robust Wald; restricted wild cluster bootstrap, fixed scope labels",
              "p": p, "resamples": CFG["resamples"], "exceedances": exceed,
              "monte_carlo_se": float(np.sqrt(p*(1-p)/(CFG["resamples"]+1))),
              "df_numerator": 2, "conservative_F_df_denominator": min(ms)-1,
              # Closed-form survival for an F distribution with numerator df = 2.
              "cluster_robust_F_reference_p": float(((min(ms)-1)/(min(ms)-1+observed))**((min(ms)-1)/2)),
              "covariance": variance.tolist(), "multicountry_minus_single_HIC_UMIC": delta.tolist(),
              "cluster_counts": ms, "bootstrap_singular_draws": singular}
    print("Geographic scope P =", p, flush=True)
    return result

def holm(values):
    values = np.asarray(values, float)
    order = np.argsort(values)
    adjusted = np.empty(len(values))
    adjusted[order] = np.minimum(1, np.maximum.accumulate(values[order] * np.arange(len(values), 0, -1)))
    return adjusted
