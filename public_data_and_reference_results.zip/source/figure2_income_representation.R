#!/usr/bin/env Rscript

# Figure 2: Trial-country participation and migraine burden by income group.
#
# This review-stage script creates one PNG only. It is presentation-only: it
# reads the frozen Phase 4 Table 2, does not refit models, and does not change
# the analytical dataset. Final TIFF, SVG, and other journal-specific exports
# will be created only after visual approval.

suppressPackageStartupMessages({
  library(digest)
  library(dplyr)
  library(ggplot2)
  library(jsonlite)
  library(readr)
})

project_root <- "[original-user]/Documents/Anti-CGRP - Geographical Disparities"
table_file <- file.path(
  project_root,
  "analysis/phase4_statistics_v2/table_2_country_representation_v2.csv"
)
output_dir <- file.path(project_root, "outputs/figures/figure2_v1_review")
script_path <- file.path(project_root, "src/figures/figure2_income_representation.R")

figure_width_mm <- 160
figure_height_mm <- 92
figure_dpi <- 300
base_font <- "Arial"

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

required_files <- c(table_file, script_path)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files) > 0) {
  stop("Missing required input(s): ", paste(missing_files, collapse = ", "))
}

table_2 <- read_csv(table_file, show_col_types = FALSE)
income_order <- c(
  "High income", "Upper-middle income", "Lower-middle income", "Low income"
)
plot_data <- table_2 %>%
  filter(`Income group (FY2019)` %in% income_order) %>%
  transmute(
    income_group = factor(`Income group (FY2019)`, levels = income_order),
    # The source field is formatted as "n (percentage)". Extract the value
    # inside parentheses so the bars represent each group's share of the
    # 453 total trial-country participations rather than the raw count.
    trial_country_participations = parse_number(sub(
      ".*\\(([^)]+)\\).*",
      "\\1",
      `Trial-country participations, n (%)`
    )),
    migraine_burden_ylds = parse_number(`Migraine burden (YLDs), %`)
  )

# Lock the visual denominator to the reviewed primary outcome.
stopifnot(nrow(plot_data) == 4)
stopifnot(sum(plot_data$trial_country_participations) == 100)
stopifnot(abs(sum(plot_data$migraine_burden_ylds) - 100) < 0.2)

plot_long <- plot_data %>%
  tidyr::pivot_longer(
    cols = c(trial_country_participations, migraine_burden_ylds),
    names_to = "measure",
    values_to = "percentage"
  ) %>%
  mutate(
    measure = factor(
      measure,
      levels = c("trial_country_participations", "migraine_burden_ylds"),
      labels = c("Trial-country participations", "Migraine burden (YLDs)")
    )
  )

figure_2 <- ggplot(plot_long, aes(x = income_group, y = percentage, fill = measure)) +
  geom_col(
    position = position_dodge(width = 0.72),
    width = 0.62,
    color = "white",
    linewidth = 0.25
  ) +
  geom_text(
    aes(label = sprintf("%.1f%%", percentage)),
    position = position_dodge(width = 0.72),
    vjust = -0.32,
    family = base_font,
    size = 2.8,
    color = "#1F1F1F"
  ) +
  scale_fill_manual(
    values = c(
      "Trial-country participations" = "#17365D",
      "Migraine burden (YLDs)" = "#A8B6C5"
    ),
    name = NULL
  ) +
  scale_y_continuous(
    name = "Share of global total (%)",
    limits = c(0, 100),
    breaks = seq(0, 100, by = 20),
    expand = expansion(mult = c(0, 0.08))
  ) +
  labs(x = NULL) +
  theme_classic(base_family = base_font, base_size = 9) +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    axis.title.y = element_text(margin = margin(r = 5), size = 8.5),
    axis.text.x = element_text(size = 8, color = "#1F1F1F"),
    axis.text.y = element_text(size = 8, color = "#1F1F1F"),
    axis.line.x = element_line(color = "#4A4A4A", linewidth = 0.3),
    axis.line.y = element_line(color = "#4A4A4A", linewidth = 0.3),
    axis.ticks = element_line(color = "#4A4A4A", linewidth = 0.3),
    legend.position = "top",
    legend.direction = "horizontal",
    legend.text = element_text(size = 8),
    legend.key.width = grid::unit(4, "mm"),
    legend.key.height = grid::unit(3, "mm"),
    plot.margin = margin(4, 5, 3, 5, unit = "mm")
  )

png_file <- file.path(output_dir, "Figure_2_review.png")
ragg::agg_png(
  png_file,
  width = figure_width_mm,
  height = figure_height_mm,
  units = "mm",
  res = figure_dpi,
  background = "white"
)
print(figure_2)
invisible(dev.off())

write_csv(plot_data, file.path(output_dir, "Figure_2_plot_data.csv"))
legend_text <- paste0(
  "## Figure 2. Geographic representation of anti-CGRP migraine trials by ",
  "World Bank income group\n\n",
  "Bars compare each income group's share of all 453 trial-country ",
  "participations with its share of the 2019 global migraine YLD burden ",
  "across 194 WHO Member States. Each trial contributes one participation to ",
  "each country represented by a non-removed registry location; participations ",
  "are not fractionally allocated. Income groups use the fixed World Bank FY2019 ",
  "classification. Abbreviations: CGRP, calcitonin gene-related peptide; WHO, ",
  "World Health Organization; YLD, year lived with disability.\n"
)
writeLines(legend_text, file.path(output_dir, "Figure_2_legend.md"), useBytes = TRUE)

capture.output(sessionInfo(), file = file.path(output_dir, "Figure_2_session_info.txt"))
manifest <- list(
  figure = "Figure 2",
  version = "figure2_v1_review",
  stage = "review_png_only",
  generated_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
  purpose = "Presentation-only comparison of trial participation and migraine burden by income group.",
  analytical_checks = list(
    who_member_states = 194,
    trial_country_participations = 453,
    plotted_income_groups = income_order,
    fractional_weighting = FALSE,
    migraine_yld_source_year = 2019
  ),
  export = list(
    format = "PNG review copy only",
    width_mm = figure_width_mm,
    height_mm = figure_height_mm,
    raster_dpi = figure_dpi,
    font = base_font,
    title_embedded_in_figure = FALSE,
    final_formats_deferred_pending_visual_approval = TRUE
  ),
  input_sha256 = as.list(vapply(
    c(table_2 = table_file, script = script_path),
    digest,
    character(1),
    algo = "sha256",
    file = TRUE
  )),
  output_sha256 = list(
    png = digest(png_file, algo = "sha256", file = TRUE),
    plot_data = digest(file.path(output_dir, "Figure_2_plot_data.csv"), algo = "sha256", file = TRUE),
    legend = digest(file.path(output_dir, "Figure_2_legend.md"), algo = "sha256", file = TRUE)
  )
)
write_json(manifest, file.path(output_dir, "Figure_2_manifest.json"), auto_unbox = TRUE, pretty = TRUE)
