#!/usr/bin/env Rscript

# Figure 3: Income-group associations with country participation in trials.
#
# This review-stage script creates one PNG only. It reads the frozen Phase 4
# comparison table and visualizes the already-estimated models; it does not
# refit any model or modify the analytical dataset. Journal export formats are
# intentionally deferred until the visual design is approved.

suppressPackageStartupMessages({
  library(digest)
  library(dplyr)
  library(ggplot2)
  library(jsonlite)
  library(patchwork)
  library(readr)
  library(stringr)
})

project_root <- "[original-user]/Documents/Anti-CGRP - Geographical Disparities"
table_file <- file.path(
  project_root,
  "analysis/phase4_statistics_v2/table_4_income_group_comparisons_v2.csv"
)
output_dir <- file.path(project_root, "outputs/figures/figure3_v1_review")
script_path <- file.path(project_root, "src/figures/figure3_income_group_associations.R")

figure_width_mm <- 180
figure_height_mm <- 110
figure_dpi <- 300
base_font <- "Arial"

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
if (!file.exists(table_file) || !file.exists(script_path)) {
  stop("Required Figure 3 input or source script is missing.")
}

# Extract a numeric estimate and its 95% confidence interval from a table cell
# formatted as, for example, "7.37 (3.58–15.21)". Non-estimable values stay
# explicitly missing and are retained as labelled rows in the visual.
parse_effect <- function(value) {
  if (is.na(value) || value == "Not estimable") {
    return(c(estimate = NA_real_, lower = NA_real_, upper = NA_real_))
  }
  numbers <- str_extract_all(value, "[0-9]+(?:\\.[0-9]+)?")[[1]]
  if (length(numbers) != 3) {
    stop("Could not parse effect estimate: ", value)
  }
  stats::setNames(as.numeric(numbers), c("estimate", "lower", "upper"))
}

comparison_order <- c(
  "HIC vs UMIC/LMIC/LIC",
  "HIC vs LMIC/LIC",
  "HIC vs UMIC",
  "HIC vs LMIC",
  "HIC vs LIC"
)

table_4 <- read_csv(table_file, show_col_types = FALSE) %>%
  filter(Comparison %in% comparison_order) %>%
  # The first factor level is drawn at the top of this ggplot forest layout.
  # This displays the prespecified primary comparison first.
  mutate(Comparison = factor(Comparison, levels = comparison_order))

if (nrow(table_4) != length(comparison_order)) {
  stop("Table 4 does not contain the expected income-group comparisons.")
}

make_effect_data <- function(data, estimate_column, p_column, outcome_label) {
  effects <- as.data.frame(t(vapply(
    data[[estimate_column]], parse_effect, numeric(3), USE.NAMES = FALSE
  )))
  names(effects) <- c("estimate", "lower", "upper")
  effects <- effects %>%
    mutate(
      Comparison = data$Comparison,
      p_value = data[[p_column]],
      outcome = outcome_label,
      estimate_label = ifelse(
        is.na(estimate),
        "Not estimable",
        sprintf("%.2f (%.2f–%.2f)", estimate, lower, upper)
      )
    )
  effects
}

or_data <- make_effect_data(
  table_4,
  "OR for any trial participation (95% CI)",
  "P value for OR",
  "Odds ratio"
)
irr_data <- make_effect_data(
  table_4,
  "IRR for trial-country participations (95% CI)",
  "P value for IRR",
  "Incidence rate ratio"
)

# A common y-axis preserves direct row-to-row comparison. Each panel uses its
# own log scale, because confidence-interval widths differ substantially
# between binary participation and count participation models.
make_forest_panel <- function(data, panel_title, axis_label, x_limits, x_breaks, show_y_axis) {
  point_data <- filter(data, !is.na(estimate))
  text_data <- filter(data, is.na(estimate))

  ggplot(data, aes(y = Comparison)) +
    geom_vline(xintercept = 1, linetype = "dashed", linewidth = 0.35, color = "#595959") +
    geom_errorbar(
      data = point_data,
      aes(xmin = lower, xmax = upper),
      width = 0.16,
      orientation = "y",
      linewidth = 0.45,
      color = "#17365D"
    ) +
    geom_point(
      data = point_data,
      aes(x = estimate),
      size = 2.35,
      shape = 21,
      fill = "#17365D",
      color = "#17365D"
    ) +
    geom_text(
      data = text_data,
      aes(x = x_limits[1] * 1.12, label = estimate_label),
      hjust = 0,
      size = 2.55,
      family = base_font,
      fontface = "italic",
      color = "#595959"
    ) +
    scale_x_log10(
      name = axis_label,
      limits = x_limits,
      breaks = x_breaks,
      labels = scales::label_number(accuracy = 0.01)
    ) +
    # Explicit limits make the primary HIC-versus-all-other-groups comparison
    # the top row regardless of the input-table row order.
    scale_y_discrete(name = NULL, limits = rev(comparison_order)) +
    labs(title = panel_title) +
    coord_cartesian(clip = "off") +
    theme_classic(base_family = base_font, base_size = 9) +
    theme(
      axis.text.y = if (show_y_axis) {
        element_text(size = 8, color = "#1F1F1F")
      } else {
        element_blank()
      },
      axis.ticks.y = if (show_y_axis) element_line(color = "#4A4A4A", linewidth = 0.3) else element_blank(),
      axis.text.x = element_text(size = 7.5, color = "#1F1F1F"),
      axis.title.x = element_text(size = 8.5, margin = margin(t = 5)),
      plot.title = element_text(size = 9, face = "bold", hjust = 0, margin = margin(b = 7)),
      axis.line = element_line(color = "#4A4A4A", linewidth = 0.3),
      axis.ticks = element_line(color = "#4A4A4A", linewidth = 0.3),
      panel.grid.major.x = element_line(color = "#D9D9D9", linewidth = 0.25),
      panel.grid.minor.x = element_blank(),
      plot.margin = margin(4, 5, 4, 4, unit = "mm")
    )
}

or_panel <- make_forest_panel(
  or_data,
  "A. Any trial participation",
  "Odds ratio (95% CI)",
  c(0.5, 65),
  c(0.5, 1, 2, 5, 10, 20, 50),
  TRUE
)
irr_panel <- make_forest_panel(
  irr_data,
  "B. Trial-country participations",
  "Incidence rate ratio (95% CI)",
  c(0.1, 1600),
  c(0.1, 1, 10, 100, 1000),
  FALSE
)

figure_3 <- or_panel + irr_panel + plot_layout(widths = c(1.15, 1))

png_file <- file.path(output_dir, "Figure_3_review.png")
ragg::agg_png(
  png_file,
  width = figure_width_mm,
  height = figure_height_mm,
  units = "mm",
  res = figure_dpi,
  background = "white"
)
print(figure_3)
invisible(dev.off())

plot_data <- bind_rows(or_data, irr_data) %>%
  select(Comparison, outcome, estimate, lower, upper, p_value, estimate_label)
write_csv(plot_data, file.path(output_dir, "Figure_3_plot_data.csv"))

legend_text <- paste0(
  "## Figure 3. Income-group associations with anti-CGRP migraine trial participation\n\n",
  "Forest plots show the univariable association of income group with (left) ",
  "the odds that a WHO Member State had at least one trial-country participation ",
  "and (right) the incidence rate of trial-country participations. Estimates ",
  "compare high-income countries (HICs) with each named comparator; values above ",
  "1 indicate greater participation for HICs. Points are estimates and horizontal ",
  "lines are 95% confidence intervals; the dashed line denotes the null value. ",
  "The HIC versus LIC comparison was not estimable because no low-income country ",
  "had a trial-country participation. Models use 192 WHO Member States with ",
  "available FY2019 World Bank income classification. Abbreviations: HIC, high-income ",
  "country; UMIC, upper-middle-income country; LMIC, lower-middle-income country; ",
  "LIC, low-income country; OR, odds ratio; IRR, incidence rate ratio; WHO, World ",
  "Health Organization.\n"
)
writeLines(legend_text, file.path(output_dir, "Figure_3_legend.md"), useBytes = TRUE)

capture.output(sessionInfo(), file = file.path(output_dir, "Figure_3_session_info.txt"))
manifest <- list(
  figure = "Figure 3",
  version = "figure3_v1_review",
  stage = "review_png_only",
  generated_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
  purpose = "Forest plots of income-group associations with trial participation.",
  analytical_checks = list(
    who_member_states_with_income_group = 192,
    comparison_order = comparison_order,
    models_refit = FALSE,
    reference_group = "High income",
    null_value = 1
  ),
  export = list(
    format = "PNG review copy only",
    width_mm = figure_width_mm,
    height_mm = figure_height_mm,
    raster_dpi = figure_dpi,
    font = base_font,
    title_embedded_in_figure = FALSE,
    final_formats_deferred_pending_visual_approval = TRUE
  ),
  input_sha256 = as.list(vapply(
    c(table_4 = table_file, script = script_path),
    digest,
    character(1),
    algo = "sha256",
    file = TRUE
  )),
  output_sha256 = list(
    png = digest(png_file, algo = "sha256", file = TRUE),
    plot_data = digest(file.path(output_dir, "Figure_3_plot_data.csv"), algo = "sha256", file = TRUE),
    legend = digest(file.path(output_dir, "Figure_3_legend.md"), algo = "sha256", file = TRUE)
  )
)
write_json(manifest, file.path(output_dir, "Figure_3_manifest.json"), auto_unbox = TRUE, pretty = TRUE)
