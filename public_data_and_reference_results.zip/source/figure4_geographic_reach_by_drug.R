#!/usr/bin/env Rscript

# Figure 4: Geographic reach by anti-CGRP monoclonal antibody category.
#
# This review-stage script creates one PNG only. It reads the frozen Phase 4
# geographic-reach table and changes presentation only; no analytical model is
# fitted and no study-level classification is modified. Final journal export
# formats are intentionally deferred until the figure is visually approved.

suppressPackageStartupMessages({
  library(digest)
  library(dplyr)
  library(ggplot2)
  library(jsonlite)
  library(patchwork)
  library(readr)
  library(tidyr)
})

project_root <- "[original-user]/Documents/Anti-CGRP - Geographical Disparities"
table_file <- file.path(
  project_root,
  "analysis/phase4_statistics_v2/table_5_geographic_reach_v2.csv"
)
output_dir <- file.path(project_root, "outputs/figures/figure4_v1_review")
script_path <- file.path(project_root, "src/figures/figure4_geographic_reach_by_drug.R")

figure_width_mm <- 180
figure_height_mm <- 112
figure_dpi <- 300
base_font <- "Arial"

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
if (!file.exists(table_file) || !file.exists(script_path)) {
  stop("Required Figure 4 input or source script is missing.")
}

# Extract the percentage from a source cell formatted as "n (percentage)".
parse_parenthetical_percentage <- function(value) {
  parse_number(sub(".*\\(([^)]+)\\).*", "\\1", value))
}

drug_order <- c(
  "Erenumab",
  "Eptinezumab",
  "Fremanezumab",
  "Galcanezumab",
  "Multiple anti-CGRP mAbs"
)

table_5 <- read_csv(table_file, show_col_types = FALSE)
drug_data <- table_5 %>%
  filter(Characteristic == "Anti-CGRP monoclonal antibody") %>%
  transmute(
    drug = Category,
    trials = as.numeric(`Trials, n`),
    countries_reached = as.numeric(`WHO countries reached, n`),
    trial_country_participations = as.numeric(`Trial-country participations, n`),
    HIC = parse_parenthetical_percentage(`HIC, n (%)`),
    UMIC = parse_parenthetical_percentage(`UMIC, n (%)`),
    LMIC = parse_parenthetical_percentage(`LMIC, n (%)`),
    LIC = parse_parenthetical_percentage(`LIC, n (%)`),
    category_type = if_else(
      drug %in% c("Multiple anti-CGRP mAbs", "Unspecified anti-CGRP mAb"),
      "Combined or unspecified",
      "Individual mAb"
    )
  )

stopifnot(nrow(drug_data) == 6)
stopifnot(setequal(
  drug_data$drug,
  c(drug_order, "Unspecified anti-CGRP mAb")
))
stopifnot(sum(drug_data$trials) == 106)
stopifnot(sum(drug_data$trial_country_participations) == 453)
stopifnot(all(drug_data$LIC == 0))

# The unspecified category remains in Table 5 and the audit trail but is not
# displayed in Figure 4, following the visual-review decision.
figure_data <- drug_data %>%
  filter(drug %in% drug_order)
excluded_from_display <- drug_data %>%
  filter(drug == "Unspecified anti-CGRP mAb") %>%
  mutate(exclusion_reason = "Removed from Figure 4 display by author decision; retained in Table 5.")

axis_labels <- setNames(
  paste0(
    figure_data$drug,
    "\n(n=",
    figure_data$trials,
    ifelse(figure_data$trials == 1, " trial)", " trials)")
  ),
  figure_data$drug
)

# Panel A reports geographic extent. Trial counts are included in the row
# labels, avoiding a second quantitative axis with a different denominator.
panel_a <- ggplot(
  figure_data,
  aes(y = drug, x = countries_reached, color = category_type)
) +
  geom_segment(
    aes(x = 0, xend = countries_reached, yend = drug),
    linewidth = 1.15,
    lineend = "round"
  ) +
  geom_point(size = 3.1) +
  geom_text(
    aes(label = countries_reached),
    hjust = -0.65,
    family = base_font,
    size = 3,
    color = "#1F1F1F"
  ) +
  scale_color_manual(
    values = c(
      "Individual mAb" = "#17365D",
      "Combined or unspecified" = "#7F7F7F"
    ),
    guide = "none"
  ) +
  scale_x_continuous(
    name = "WHO Member States reached, n",
    limits = c(0, 48),
    breaks = seq(0, 40, by = 10),
    expand = expansion(mult = c(0, 0.02))
  ) +
  scale_y_discrete(
    name = NULL,
    limits = rev(drug_order),
    labels = axis_labels
  ) +
  labs(title = "A. Geographic reach") +
  coord_cartesian(clip = "off") +
  theme_classic(base_family = base_font, base_size = 9) +
  theme(
    plot.title = element_text(size = 9, face = "bold", hjust = 0, margin = margin(b = 7)),
    axis.title.x = element_text(size = 8.5, margin = margin(t = 5)),
    axis.text.x = element_text(size = 7.5, color = "#1F1F1F"),
    axis.text.y = element_text(size = 7.8, color = "#1F1F1F", lineheight = 0.92),
    axis.line = element_line(color = "#4A4A4A", linewidth = 0.3),
    axis.ticks = element_line(color = "#4A4A4A", linewidth = 0.3),
    panel.grid.major.x = element_line(color = "#D9D9D9", linewidth = 0.25),
    panel.grid.minor.x = element_blank(),
    plot.margin = margin(4, 5, 4, 4, unit = "mm")
  )

income_order <- c("HIC", "UMIC", "LMIC", "LIC")
income_colors <- c(
  "HIC" = "#17365D",
  "UMIC" = "#5B7FA3",
  "LMIC" = "#A8B6C5",
  "LIC" = "#E6E6E6"
)

income_data <- figure_data %>%
  select(drug, HIC, UMIC, LMIC, LIC) %>%
  pivot_longer(
    cols = all_of(income_order),
    names_to = "income_group",
    values_to = "percentage"
  ) %>%
  mutate(
    income_group = factor(income_group, levels = income_order),
    percentage_label = if_else(percentage >= 8, sprintf("%.1f%%", percentage), ""),
    label_color = if_else(income_group %in% c("LMIC", "LIC"), "#1F1F1F", "white")
  )

# Panel B reports distribution rather than absolute reach. Labels are shown
# only where they fit without obscuring small segments; exact values remain in
# Table 5 and in the auditable plot-data CSV.
panel_b <- ggplot(
  income_data,
  aes(y = drug, x = percentage, fill = income_group)
) +
  geom_col(
    position = position_stack(reverse = TRUE),
    width = 0.58,
    color = "white",
    linewidth = 0.18
  ) +
  geom_text(
    aes(label = percentage_label, color = label_color, group = income_group),
    position = position_stack(vjust = 0.5, reverse = TRUE),
    family = base_font,
    size = 2.45
  ) +
  scale_color_identity() +
  scale_fill_manual(
    values = income_colors,
    breaks = income_order,
    name = NULL,
    drop = FALSE
  ) +
  scale_x_continuous(
    name = "Trial-country participations (%)",
    breaks = seq(0, 100, by = 20),
    expand = expansion(mult = c(0, 0))
  ) +
  scale_y_discrete(name = NULL, limits = rev(drug_order)) +
  labs(title = "B. Distribution by income group") +
  # Coordinate clipping keeps the visual at 0–100% while retaining segments
  # whose displayed one-decimal percentages sum to 100.1% after rounding.
  coord_cartesian(xlim = c(0, 100), clip = "on") +
  theme_classic(base_family = base_font, base_size = 9) +
  theme(
    plot.title = element_text(size = 8.8, face = "bold", hjust = 0, margin = margin(b = 3)),
    axis.title.x = element_text(size = 8.2, margin = margin(t = 5)),
    axis.text.x = element_text(size = 7.5, color = "#1F1F1F"),
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.line = element_line(color = "#4A4A4A", linewidth = 0.3),
    axis.ticks = element_line(color = "#4A4A4A", linewidth = 0.3),
    legend.position = "top",
    legend.direction = "horizontal",
    legend.justification = c(0, 0.5),
    legend.box.just = "left",
    legend.text = element_text(size = 7.3),
    legend.key.width = grid::unit(3.6, "mm"),
    legend.key.height = grid::unit(2.7, "mm"),
    legend.spacing.x = grid::unit(1.5, "mm"),
    legend.margin = margin(0, 0, 3, 0, unit = "mm"),
    panel.grid.major.x = element_line(color = "#D9D9D9", linewidth = 0.25),
    panel.grid.minor.x = element_blank(),
    plot.margin = margin(4, 4, 4, 5, unit = "mm")
  )

figure_4 <- panel_a + panel_b + plot_layout(widths = c(0.86, 1.34))

png_file <- file.path(output_dir, "Figure_4_review.png")
ragg::agg_png(
  png_file,
  width = figure_width_mm,
  height = figure_height_mm,
  units = "mm",
  res = figure_dpi,
  background = "white"
)
print(figure_4)
invisible(dev.off())

write_csv(figure_data, file.path(output_dir, "Figure_4_plot_data.csv"))
write_csv(income_data, file.path(output_dir, "Figure_4_income_distribution_plot_data.csv"))
write_csv(
  excluded_from_display,
  file.path(output_dir, "Figure_4_excluded_from_display.csv")
)

legend_text <- paste0(
  "## Figure 4. Geographic reach of anti-CGRP migraine trials by monoclonal antibody category\n\n",
  "Panel A shows the number of WHO Member States reached by each mutually exclusive ",
  "anti-CGRP monoclonal antibody category; the number of included trials is provided ",
  "in parentheses. Panel B shows the distribution of trial-country participations ",
  "across World Bank FY2019 income groups. Each trial contributes one participation ",
  "to each country represented by a non-removed registry location, without fractional ",
  "allocation. Multiple anti-CGRP mAbs identifies trials evaluating more than one ",
  "included monoclonal antibody. The single trial classified as unspecified ",
  "anti-CGRP mAb is retained in Table 5 but was omitted from this figure by author ",
  "decision. Small segment labels ",
  "are omitted from the figure for readability; exact values are reported in Table 5. ",
  "No trial-country participation occurred in a low-income country. Abbreviations: ",
  "CGRP, calcitonin gene-related peptide; HIC, high-income country; UMIC, upper-middle-",
  "income country; LMIC, lower-middle-income country; LIC, low-income country; WHO, ",
  "World Health Organization.\n"
)
writeLines(legend_text, file.path(output_dir, "Figure_4_legend.md"), useBytes = TRUE)

capture.output(sessionInfo(), file = file.path(output_dir, "Figure_4_session_info.txt"))
manifest <- list(
  figure = "Figure 4",
  version = "figure4_v1_review",
  stage = "review_png_only",
  generated_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
  purpose = "Geographic extent and income-group distribution by anti-CGRP mAb category.",
  analytical_checks = list(
    included_trials = 106,
    trial_country_participations = 453,
    plotted_categories = drug_order,
    excluded_from_display = "Unspecified anti-CGRP mAb (1 trial; retained in Table 5)",
    individual_mabs = 4,
    mutually_exclusive_drug_categories = TRUE,
    fractional_weighting = FALSE,
    income_classification = "World Bank FY2019"
  ),
  export = list(
    format = "PNG review copy only",
    width_mm = figure_width_mm,
    height_mm = figure_height_mm,
    raster_dpi = figure_dpi,
    font = base_font,
    figure_title_embedded = FALSE,
    final_formats_deferred_pending_visual_approval = TRUE
  ),
  input_sha256 = as.list(vapply(
    c(table_5 = table_file, script = script_path),
    digest,
    character(1),
    algo = "sha256",
    file = TRUE
  )),
  output_sha256 = list(
    png = digest(png_file, algo = "sha256", file = TRUE),
    plot_data = digest(file.path(output_dir, "Figure_4_plot_data.csv"), algo = "sha256", file = TRUE),
    income_plot_data = digest(
      file.path(output_dir, "Figure_4_income_distribution_plot_data.csv"),
      algo = "sha256",
      file = TRUE
    ),
    excluded_from_display = digest(
      file.path(output_dir, "Figure_4_excluded_from_display.csv"),
      algo = "sha256",
      file = TRUE
    ),
    legend = digest(file.path(output_dir, "Figure_4_legend.md"), algo = "sha256", file = TRUE)
  )
)
write_json(manifest, file.path(output_dir, "Figure_4_manifest.json"), auto_unbox = TRUE, pretty = TRUE)
