#!/usr/bin/env Rscript

# Supplementary Figure 4: Trial-participation disproportionality by GDP.
#
# This review-stage script creates one PNG only. It uses the frozen cohort-v2
# country dataset, non-fractional trial-country participations, and migraine YLD
# burden as the expected-count offset. Countries with zero participation remain
# in the figure and model. Final journal formats await visual approval.

suppressPackageStartupMessages({
  library(digest)
  library(dplyr)
  library(ggplot2)
  library(ggrepel)
  library(jsonlite)
  library(MASS)
  library(readr)
  library(sandwich)
  library(sf)
})

project_root <- "[original-user]/Documents/Anti-CGRP - Geographical Disparities"
country_file <- file.path(
  project_root,
  "analysis/phase4_statistics_v2/country_level_analysis_dataset_v2.csv"
)
oe_audit_file <- file.path(
  project_root,
  "analysis/phase4_statistics_v2/table_S8_country_observed_expected_ratios_v2.csv"
)
model_file <- file.path(
  project_root,
  "analysis/phase4_statistics_v2/model_estimates_v2.csv"
)
natural_earth_file <- file.path(
  project_root,
  "data/raw/geospatial/natural_earth_50m_admin0_v5_1_1/ne_50m_admin_0_countries.shp"
)
script_path <- file.path(
  project_root,
  "src/figures/figureS4_gdp_disproportionality.R"
)
output_dir <- file.path(project_root, "outputs/figures/figureS4_gdp_v1_review")

figure_width_mm <- 175
figure_height_mm <- 118
figure_dpi <- 300
base_font <- "Arial"
label_seed <- 20260815
gdp_center <- 20000

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
required_files <- c(
  country_file, oe_audit_file, model_file, natural_earth_file, script_path
)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files) > 0) {
  stop("Missing required Figure S4 input(s): ", paste(missing_files, collapse = ", "))
}

country <- read_csv(country_file, show_col_types = FALSE)
oe_audit <- read_csv(oe_audit_file, show_col_types = FALSE)
frozen_models <- read_csv(model_file, show_col_types = FALSE)

stopifnot(nrow(country) == 194)
stopifnot(all(country$analysis_in_primary_universe == 1))
stopifnot(sum(country$trial_country_participations) == 453)
stopifnot(sum(country$trial_country_participations > 0) == 47)
stopifnot(all(country$migraine_yld_number_2019_val > 0))

total_participations <- sum(country$trial_country_participations)
total_ylds <- sum(country$migraine_yld_number_2019_val)

country_derived <- country %>%
  mutate(
    expected_participations = total_participations *
      migraine_yld_number_2019_val / total_ylds,
    observed_to_expected_ratio = trial_country_participations /
      expected_participations,
    oe_plot_scale = log10(1 + observed_to_expected_ratio)
  )

# Confirm that the displayed O/E ratio reproduces the frozen supplementary table.
oe_check <- country_derived %>%
  dplyr::select(country_iso3, observed_to_expected_ratio) %>%
  left_join(
    oe_audit %>%
      transmute(
        country_iso3 = ISO3,
        frozen_oe = `Observed-to-expected participation ratio`
      ),
    by = "country_iso3"
  )
stopifnot(!any(is.na(oe_check$frozen_oe)))
stopifnot(max(abs(
  oe_check$observed_to_expected_ratio - oe_check$frozen_oe
)) < 1e-6)

# Reproducible geographic grouping from Natural Earth region/subregion fields.
world_raw <- st_read(natural_earth_file, quiet = TRUE)
region_reference <- world_raw %>%
  mutate(
    map_iso3 = if_else(
      !is.na(ISO_A3) & ISO_A3 != "-99" & nchar(ISO_A3) == 3,
      ISO_A3,
      ADM0_A3
    ),
    world_region = case_when(
      SUBREGION == "Northern America" ~ "North America",
      SUBREGION %in% c("Caribbean", "Central America", "South America") ~
        "Latin America and the Caribbean",
      REGION_UN == "Africa" ~ "Africa",
      REGION_UN == "Asia" ~ "Asia",
      REGION_UN == "Europe" ~ "Europe",
      REGION_UN == "Oceania" ~ "Oceania",
      TRUE ~ NA_character_
    )
  ) %>%
  st_drop_geometry() %>%
  dplyr::select(
    map_iso3, natural_earth_name = ADMIN, CONTINENT, REGION_UN,
    SUBREGION, world_region
  ) %>%
  distinct(map_iso3, .keep_all = TRUE)

plot_all <- country_derived %>%
  left_join(region_reference, by = c("country_iso3" = "map_iso3"))

region_join_audit <- plot_all %>%
  transmute(
    country_iso3,
    geography_name,
    matched_natural_earth_region = !is.na(world_region),
    natural_earth_name,
    continent = CONTINENT,
    un_region = REGION_UN,
    subregion = SUBREGION,
    world_region
  )
if (any(!region_join_audit$matched_natural_earth_region)) {
  stop(
    "Country region(s) unmatched to Natural Earth: ",
    paste(
      region_join_audit$country_iso3[
        !region_join_audit$matched_natural_earth_region
      ],
      collapse = ", "
    )
  )
}

excluded_gdp <- plot_all %>%
  filter(is.na(gdp_pc_ppp_constant_2021_intl_usd_period_mean)) %>%
  transmute(
    country_iso3,
    geography_name,
    exclusion_reason = paste0(
      "Period-mean GDP per capita PPP unavailable; no imputation performed."
    )
  )

plot_data <- plot_all %>%
  filter(!is.na(gdp_pc_ppp_constant_2021_intl_usd_period_mean)) %>%
  mutate(
    log2_gdp_centered = log2(
      gdp_pc_ppp_constant_2021_intl_usd_period_mean / gdp_center
    ),
    world_region = factor(
      world_region,
      levels = c(
        "Africa", "Asia", "Europe", "North America",
        "Latin America and the Caribbean", "Oceania"
      )
    )
  )

stopifnot(nrow(plot_data) == 185)
stopifnot(nrow(excluded_gdp) == 9)
stopifnot(sum(plot_data$trial_country_participations > 0) == 47)
stopifnot(sum(plot_data$trial_country_participations == 0) == 138)

# Reconstruct the prediction curve from the prespecified burden-offset model.
# Frozen Phase 4 HC3 results remain authoritative for reported inference.
gdp_model <- glm.nb(
  trial_country_participations ~ log2_gdp_centered +
    offset(log(expected_participations)),
  data = plot_data,
  control = glm.control(maxit = 100)
)
robust_vcov <- vcovHC(gdp_model, type = "HC3")

frozen_gdp <- frozen_models %>%
  filter(model_id == "nb_gdp_ppp_per_doubling")
stopifnot(nrow(frozen_gdp) == 1)
stopifnot(frozen_gdp$status == "estimated")
stopifnot(abs(exp(coef(gdp_model)["log2_gdp_centered"]) - frozen_gdp$estimate) < 0.001)

gdp_grid <- 2^seq(
  log2(min(plot_data$gdp_pc_ppp_constant_2021_intl_usd_period_mean)),
  log2(max(plot_data$gdp_pc_ppp_constant_2021_intl_usd_period_mean)),
  length.out = 250
)
design_grid <- cbind(
  `(Intercept)` = 1,
  log2_gdp_centered = log2(gdp_grid / gdp_center)
)
link_fit <- drop(design_grid %*% coef(gdp_model))
link_se <- sqrt(rowSums((design_grid %*% robust_vcov) * design_grid))

prediction_data <- tibble(
  gdp = gdp_grid,
  predicted_oe = exp(link_fit),
  predicted_oe_lower = exp(link_fit - qnorm(0.975) * link_se),
  predicted_oe_upper = exp(link_fit + qnorm(0.975) * link_se),
  predicted_plot = log10(1 + predicted_oe),
  predicted_plot_lower = log10(1 + predicted_oe_lower),
  predicted_plot_upper = log10(1 + predicted_oe_upper)
)

# Prespecified deterministic ISO3 labelling rule.
highest_oe <- plot_data %>%
  filter(observed_to_expected_ratio > 0) %>%
  arrange(desc(observed_to_expected_ratio), country_iso3) %>%
  slice_head(n = 5) %>%
  mutate(label_reason = "Five highest O/E ratios")

lowest_positive_oe <- plot_data %>%
  filter(observed_to_expected_ratio > 0) %>%
  arrange(observed_to_expected_ratio, country_iso3) %>%
  slice_head(n = 5) %>%
  mutate(label_reason = "Five lowest positive O/E ratios")

highest_expected_zero <- plot_data %>%
  filter(observed_to_expected_ratio == 0) %>%
  arrange(desc(expected_participations), country_iso3) %>%
  slice_head(n = 5) %>%
  mutate(label_reason = "Five highest expected counts among O/E = 0 countries")

label_data <- bind_rows(
  highest_oe,
  lowest_positive_oe,
  highest_expected_zero
) %>%
  distinct(country_iso3, .keep_all = TRUE) %>%
  dplyr::select(
    country_iso3, geography_name,
    gdp_pc_ppp_constant_2021_intl_usd_period_mean,
    oe_plot_scale, observed_to_expected_ratio,
    expected_participations, label_reason
  )

plot_data <- plot_data %>%
  left_join(
    label_data %>% dplyr::select(country_iso3, label_reason),
    by = "country_iso3"
  ) %>%
  mutate(iso3_label = if_else(!is.na(label_reason), country_iso3, NA_character_))

region_colors <- c(
  "Africa" = "#332288",
  "Asia" = "#DDCC77",
  "Europe" = "#117733",
  "North America" = "#88CCEE",
  "Latin America and the Caribbean" = "#CC6677",
  "Oceania" = "#AA4499"
)

oe_breaks <- c(0, 0.1, 0.25, 0.5, 1, 2, 5, 10, 20, 50)
oe_break_positions <- log10(1 + oe_breaks)
oe_break_labels <- c("0", "0.1", "0.25", "0.5", "1", "2", "5", "10", "20", "50")

model_annotation <- paste0(
  "Burden-adjusted IRR per doubling of GDP per capita: ",
  sprintf("%.2f", frozen_gdp$estimate),
  " (95% CI, ", sprintf("%.2f", frozen_gdp$ci_lower),
  "–", sprintf("%.2f", frozen_gdp$ci_upper), "); ",
  ifelse(
    frozen_gdp$p_value < 0.001,
    "P < .001",
    paste0("P = ", sprintf("%.3f", frozen_gdp$p_value))
  )
)

figure_s4 <- ggplot(
  plot_data,
  aes(
    x = gdp_pc_ppp_constant_2021_intl_usd_period_mean,
    y = oe_plot_scale
  )
) +
  geom_hline(yintercept = 0, linewidth = 0.3, color = "#9A9A9A") +
  geom_hline(
    yintercept = log10(2),
    linetype = "dashed",
    linewidth = 0.4,
    color = "#595959"
  ) +
  geom_ribbon(
    data = prediction_data,
    aes(x = gdp, ymin = predicted_plot_lower, ymax = predicted_plot_upper),
    inherit.aes = FALSE,
    fill = "#8FAFC7",
    alpha = 0.28
  ) +
  geom_line(
    data = prediction_data,
    aes(x = gdp, y = predicted_plot),
    inherit.aes = FALSE,
    color = "#17365D",
    linewidth = 0.8
  ) +
  geom_point(
    aes(fill = world_region, size = expected_participations),
    shape = 21,
    color = "white",
    stroke = 0.28,
    alpha = 0.88
  ) +
  geom_text_repel(
    data = filter(plot_data, label_reason == "Five highest O/E ratios"),
    aes(label = iso3_label),
    seed = label_seed,
    nudge_y = 0.035,
    ylim = c(log10(3), log10(64)),
    direction = "y",
    size = 2.55,
    family = base_font,
    fontface = "bold",
    color = "#1F1F1F",
    box.padding = 0.24,
    point.padding = 0.16,
    min.segment.length = 0,
    segment.color = "#7F7F7F",
    segment.size = 0.25,
    max.overlaps = Inf,
    show.legend = FALSE
  ) +
  geom_text_repel(
    data = filter(
      plot_data,
      label_reason == "Five lowest positive O/E ratios"
    ),
    aes(label = iso3_label),
    seed = label_seed + 1,
    nudge_y = 0.10,
    ylim = c(0.07, 0.24),
    size = 2.55,
    family = base_font,
    fontface = "bold",
    color = "#1F1F1F",
    box.padding = 0.24,
    point.padding = 0.16,
    min.segment.length = 0,
    segment.color = "#7F7F7F",
    segment.size = 0.25,
    max.overlaps = Inf,
    show.legend = FALSE
  ) +
  geom_text_repel(
    data = filter(
      plot_data,
      label_reason == "Five highest expected counts among O/E = 0 countries"
    ),
    aes(label = iso3_label),
    seed = label_seed + 2,
    nudge_y = -0.085,
    ylim = c(-0.125, -0.035),
    direction = "x",
    size = 2.55,
    family = base_font,
    fontface = "bold",
    color = "#1F1F1F",
    box.padding = 0.24,
    point.padding = 0.16,
    min.segment.length = 0,
    segment.color = "#7F7F7F",
    segment.size = 0.25,
    max.overlaps = Inf,
    show.legend = FALSE
  ) +
  annotate(
    "text",
    x = min(plot_data$gdp_pc_ppp_constant_2021_intl_usd_period_mean) * 1.05,
    y = log10(2) + 0.035,
    label = "Proportional representation (O/E = 1)",
    hjust = 0,
    vjust = 0,
    family = base_font,
    size = 2.55,
    color = "#4A4A4A"
  ) +
  annotate(
    "text",
    x = min(plot_data$gdp_pc_ppp_constant_2021_intl_usd_period_mean) * 1.05,
    y = log10(65),
    label = model_annotation,
    hjust = 0,
    vjust = 1,
    family = base_font,
    size = 2.65,
    color = "#1F1F1F"
  ) +
  scale_fill_manual(
    values = region_colors,
    breaks = names(region_colors),
    drop = FALSE,
    name = "World region"
  ) +
  scale_size_continuous(
    trans = "sqrt",
    range = c(1.6, 5.3),
    breaks = c(1, 10, 50),
    name = "Expected participations"
  ) +
  scale_x_continuous(
    trans = "log2",
    name = "GDP per capita, PPP, period mean (constant 2021 international $)",
    breaks = c(1000, 2000, 5000, 10000, 20000, 50000, 100000),
    labels = c("$1k", "$2k", "$5k", "$10k", "$20k", "$50k", "$100k"),
    expand = expansion(mult = c(0.025, 0.055))
  ) +
  scale_y_continuous(
    name = "Observed-to-expected participation ratio",
    breaks = oe_break_positions,
    labels = oe_break_labels,
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  coord_cartesian(ylim = c(-0.14, log10(66)), clip = "off") +
  guides(
    fill = guide_legend(
      order = 1,
      nrow = 2,
      byrow = TRUE,
      override.aes = list(size = 3.2, alpha = 1)
    ),
    size = guide_legend(
      order = 2,
      nrow = 1,
      title.position = "left",
      byrow = TRUE,
      override.aes = list(
        shape = 21,
        fill = "#B8B8B8",
        color = "#666666",
        alpha = 1
      )
    )
  ) +
  theme_classic(base_family = base_font, base_size = 9) +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    axis.title = element_text(size = 8.6, color = "#1F1F1F"),
    axis.title.x = element_text(margin = margin(t = 5)),
    axis.title.y = element_text(margin = margin(r = 5)),
    axis.text = element_text(size = 7.6, color = "#1F1F1F"),
    axis.line = element_line(color = "#4A4A4A", linewidth = 0.3),
    axis.ticks = element_line(color = "#4A4A4A", linewidth = 0.3),
    panel.grid.major.y = element_line(color = "#E2E2E2", linewidth = 0.25),
    panel.grid.minor = element_blank(),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.title = element_text(size = 7.5, face = "bold"),
    legend.text = element_text(size = 7.2),
    legend.key.width = grid::unit(4.0, "mm"),
    legend.key.height = grid::unit(3.0, "mm"),
    legend.spacing.y = grid::unit(0.8, "mm"),
    plot.margin = margin(5, 8, 4, 5, unit = "mm")
  )

png_file <- file.path(output_dir, "Figure_S4_review.png")
ragg::agg_png(
  png_file,
  width = figure_width_mm,
  height = figure_height_mm,
  units = "mm",
  res = figure_dpi,
  background = "white"
)
print(figure_s4)
invisible(dev.off())

write_csv(
  plot_data %>%
    transmute(
      country_iso3,
      country = geography_name,
      world_region,
      gdp_pc_ppp_constant_2021_intl_usd_period_mean,
      migraine_yld_number_2019_val,
      observed_participations = trial_country_participations,
      expected_participations,
      observed_to_expected_ratio,
      displayed_scale_log10_1_plus_oe = oe_plot_scale,
      point_label = iso3_label,
      label_reason
    ) %>%
    arrange(country_iso3),
  file.path(output_dir, "Figure_S4_country_plot_data.csv")
)
write_csv(
  label_data %>% arrange(label_reason, country_iso3),
  file.path(output_dir, "Figure_S4_label_selection_audit.csv")
)
write_csv(
  excluded_gdp %>% arrange(country_iso3),
  file.path(output_dir, "Figure_S4_excluded_missing_gdp.csv")
)
write_csv(
  region_join_audit %>% arrange(country_iso3),
  file.path(output_dir, "Figure_S4_region_join_audit.csv")
)
write_csv(
  tibble(
    model = "Negative-binomial count model with migraine YLD expected-count offset",
    formula = "trial-country participations ~ log2(GDP per capita PPP) + offset(log(expected participations))",
    countries_n = nrow(plot_data),
    countries_with_zero_participations_n = sum(plot_data$trial_country_participations == 0),
    estimate_type = "IRR per doubling of GDP per capita PPP",
    frozen_estimate = frozen_gdp$estimate,
    frozen_ci_lower = frozen_gdp$ci_lower,
    frozen_ci_upper = frozen_gdp$ci_upper,
    frozen_p_value = frozen_gdp$p_value,
    r_curve_estimate = exp(coef(gdp_model)["log2_gdp_centered"]),
    r_curve_robust_covariance = "HC3 sandwich covariance",
    negative_binomial_theta = gdp_model$theta,
    models_refit_for_inference = FALSE,
    curve_reconstruction_note = paste0(
      "The model was reconstructed in R only to draw the prediction curve; ",
      "reported inference is the frozen Phase 4 statsmodels HC3 result."
    )
  ),
  file.path(output_dir, "Figure_S4_model_audit.csv")
)

excluded_names <- paste(excluded_gdp$geography_name, collapse = ", ")
legend_text <- paste0(
  "## Supplementary Figure 4. GDP per capita and burden-adjusted geographic ",
  "representation of anti-CGRP migraine trials\n\n",
  "Each point represents a World Health Organization Member State with available ",
  "period-mean GDP per capita at purchasing power parity (PPP), expressed in constant ",
  "2021 international dollars. The observed-to-expected participation ratio compares ",
  "non-fractional trial-country participations with the number expected from the ",
  "country's share of 2019 migraine years lived with disability (YLDs); a ratio of 1 ",
  "denotes proportional representation. The y-axis uses log10(1 + O/E) spacing while ",
  "displaying the original O/E values, retaining countries with zero participation. ",
  "The x-axis is logarithmic, and the incidence rate ratio (IRR) is interpreted per ",
  "doubling of GDP per capita. Point area reflects expected participations. The line ",
  "and band show the burden-offset negative-binomial mean and 95% confidence interval; ",
  "reported inference is the frozen Phase 4 HC3-robust result. ISO3 labels identify ",
  "the five highest O/E ratios, five lowest positive O/E ratios, and five highest ",
  "expected counts among countries with O/E = 0. Nine countries without period-mean ",
  "GDP per capita PPP were excluded without imputation: ", excluded_names, ". ",
  "Geographic groups are derived from Natural Earth region and subregion fields. ",
  "Abbreviations: CGRP, calcitonin gene-related peptide; CI, confidence interval; ",
  "GDP, gross domestic product; IRR, incidence rate ratio; O/E, observed-to-expected; ",
  "PPP, purchasing power parity; YLD, year lived with disability.\n"
)
writeLines(legend_text, file.path(output_dir, "Figure_S4_legend.md"), useBytes = TRUE)

capture.output(sessionInfo(), file = file.path(output_dir, "Figure_S4_session_info.txt"))
manifest <- list(
  figure = "Supplementary Figure 4",
  version = "figureS4_gdp_v1_review",
  stage = "review_png_only",
  generated_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
  analytical_checks = list(
    who_member_states = 194,
    countries_with_gdp = 185,
    countries_without_gdp = 9,
    countries_with_positive_participation = 47,
    countries_with_zero_participation = 138,
    total_trial_country_participations = 453,
    fractional_weighting = FALSE,
    gdp_measure = "PPP, constant 2021 international dollars, period mean",
    expected_count_basis = "Country share of 2019 migraine YLD number",
    displayed_y_transform = "log10(1 + observed-to-expected ratio)",
    zero_values_retained = TRUE,
    label_selection_seed = label_seed,
    label_rule = c(
      "five highest O/E",
      "five lowest positive O/E",
      "five highest expected counts among O/E = 0 countries"
    )
  ),
  model = list(
    frozen_model_id = frozen_gdp$model_id,
    estimate = frozen_gdp$estimate,
    ci_lower = frozen_gdp$ci_lower,
    ci_upper = frozen_gdp$ci_upper,
    p_value = frozen_gdp$p_value,
    curve_reconstructed_in_r = TRUE,
    inference_replaced = FALSE
  ),
  export = list(
    format = "PNG review copy only",
    width_mm = figure_width_mm,
    height_mm = figure_height_mm,
    raster_dpi = figure_dpi,
    font = base_font,
    title_embedded_in_figure = FALSE,
    final_formats_deferred_pending_visual_approval = TRUE
  ),
  input_sha256 = as.list(vapply(
    c(
      country_dataset = country_file,
      frozen_oe_table = oe_audit_file,
      frozen_model_estimates = model_file,
      natural_earth_shapefile = natural_earth_file,
      script = script_path
    ),
    digest,
    character(1),
    algo = "sha256",
    file = TRUE
  )),
  output_sha256 = list(
    png = digest(png_file, algo = "sha256", file = TRUE),
    plot_data = digest(
      file.path(output_dir, "Figure_S4_country_plot_data.csv"),
      algo = "sha256", file = TRUE
    ),
    label_audit = digest(
      file.path(output_dir, "Figure_S4_label_selection_audit.csv"),
      algo = "sha256", file = TRUE
    ),
    model_audit = digest(
      file.path(output_dir, "Figure_S4_model_audit.csv"),
      algo = "sha256", file = TRUE
    ),
    legend = digest(
      file.path(output_dir, "Figure_S4_legend.md"),
      algo = "sha256", file = TRUE
    )
  )
)
write_json(manifest, file.path(output_dir, "Figure_S4_manifest.json"), auto_unbox = TRUE, pretty = TRUE)
